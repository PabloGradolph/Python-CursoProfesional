# Este es un comentario en python

# Este es otro comentario en python
# aunque lo hemos escrito en dos lineas

""" Este es un comentario multilinea. La
siguiente parte realiza una serie
de cosas muy chulas """

""" Aunque es multilinea, sólo usamos una """
