'VARIABLES'
'Las variables en Python no requieren declarar la variable antes de usarla'

'ENTEROS'
numeroEntero = 12
sumaEntero = numeroEntero + 10
print(sumaEntero)

'DECIMALES'
numeroDecimal = 12.8
sumaDecimal = numeroDecimal + 10
print(sumaDecimal)

'CADENAS'
nombre = "Pedro "
print(nombre)
apellidos = "Gutierrez Alvarez"
print(nombre + apellidos)
frase = "El me dijo: '¡hola como estas!'"
print(frase)
comillasDobles = "Ella me dijo: \"HOLA\""
print(comillasDobles)
fraseIntro = "Ella me dijo: \n\"HOLA\""
print(fraseIntro)
print(nombre * 3)


#CONVERSION DE TIPOS O CASTING
numeroEntero = int(numeroDecimal)
print(numeroEntero)

numeroDecimal = float(numeroEntero)
print(numeroDecimal)

otroNumero = str(10)
print(otroNumero * 2)