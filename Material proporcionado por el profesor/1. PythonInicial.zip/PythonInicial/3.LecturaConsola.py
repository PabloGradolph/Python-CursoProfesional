#SOLICITANDO DATOS POR CONSOLA

# La funcion inpunt() nos permite leer cualquier dato introducido por consola
print("Introduce tu nombre: ")
nombre = input()
print("Introduce tu edad: ")
edad = input()
print("Introduce tu peso: ")
peso = input()
print("Hola: ", nombre, " tienes: ", edad, " años, y pesas: ", peso, " kg.")