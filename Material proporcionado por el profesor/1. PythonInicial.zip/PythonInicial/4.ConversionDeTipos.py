#SOLICITANDO DATOS POR CONSOLA Y CONVIRTIENDOLOS

#Si esto lo dejo asi, al leer un dato por consola este se recibe como si fuera una cadena de texto

print("Introduce un numero:")
numeroUno = input()
print("Introduce otro numero:")
numeroDos = input()
print(numeroUno + numeroDos)

#Para solucionarlo habria que convertirlo
print("Introduce un numero:")
numeroUno = int(input())
print("Introduce otro numero:")
numeroDos = int(input())
print(numeroUno + numeroDos)
