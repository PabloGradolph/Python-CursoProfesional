#OPERADORES MATEMATICOS

'+, -, *, /, // (parte entera de la division), ** (potencia)'

'SUMA'
print("Suma:", 2 + 2)

'RESTA'
print("Resta:", 2 - 2)

'MULTIPLICACION'
print("Multiplicacion:", 2 * 2)

'DIVISION'
print("Division:", 2 / 2)

'PARTE ENTERA DE UNA DIVISION'
print("Parte entera de la division:", 19 // 2)

'MODULO O RESTO - DEVUELVE EL RESTO DE LA DIVISION'
print("Resto de la division:", 35 % 3)

'POTENCIA'
print(2 * 2 * 2 * 2 * 2)
print(2 ** 5)




#OPERADORES DE ASIGNACION
# ==
# +=
# -=
# /=
# %=
# **=
# //=

"""numero = 10
numero = numero + 2
print(numero)"""

numero = 10
numero += 2
print(numero)




#OPERADORES DE COMPARACION

# <	Menor que
# >	Mayor que
# <= Menor o igual que
# >= Mayor o igual que
# == Igual a
# != Distinto de

valor1 = 2
valor2 = 9

operacion1 = valor1 < 3
print(operacion1)

operacion2 = valor2 == 6
print(operacion2)


#OPERADORES LOGICOS

# and
# or
# not

valor3 = 2
valor4 = 9

operacion3 = ((valor3 < 3) and (valor4 == 6))
print(operacion3)

operacion4 = ((valor3 < 3) or (valor4 == 6))
print(operacion4)

operacion5 = not ((valor3 < 3) | (valor4 == 6))
print(operacion5)
