edad = 5

if edad >= 18:
    print("Puedes entrar enseñando el carnet")
elif edad == 20:
    print("Puedes entrar")
elif edad >= 50:
    print("No puedes entrar, eres muy mayor")
else:
    print("No puedes entrar")
