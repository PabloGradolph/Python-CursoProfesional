#BUCLE FOR


#BUCLE FOR ASCENDENTE
for vuelta in range(0, 10):
    print("Vuelta "+str(vuelta))



#BUCLE FOR DESCENDENTE
num=50
for i in range(1, num + 1):
     print(num - i)



#BUCLE FOR DE DOS EN DOS
for vuelta in range(0, 10, 2):
    print("Vuelta "+str(vuelta))



#BUCLE FOR PARA TRABAJAR CON CADENAS
for letter in "JUNIOR":
    if letter=="I":
        print("i")
    else:
        print("Letra:", letter)

