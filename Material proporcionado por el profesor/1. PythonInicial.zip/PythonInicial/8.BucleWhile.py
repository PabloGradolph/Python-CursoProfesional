#BUCLE WHILE

manzanas = 10

while manzanas > 0:
    print("Me estoy comiendo la manzana", manzanas)
    manzanas -= 1

print("Me he quedado sin manzanas")