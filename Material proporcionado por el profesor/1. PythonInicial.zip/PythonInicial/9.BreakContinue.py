#SENTENCIAS BREAK Y CONTINUE

for i in range(0, 10):
    if i == 5:
        break
    print("El valor de i es", i)


for i in range(0, 10):
    if i == 5:
        continue
    print("El valor de i es", i)