# TRATAMIENTO DE CADENAS DE CARACTERES EN PYTHON

# Incluyendo comillas simples y dobles dentro de una cadena
print("Esta \"palabra\" se encuentra escrita entre comillas dobles \"")

# Incluyendo comillas simples y dobles dentro de una cadena
print("Esta 'palabra' se encuentra escrita entre comillas simples")
print("Esta \"palabra\" se encuentra escrita entre comillas dobles")

# carácteres especiales como las tabulaciones /t o los saltos de línea /n
print("Un texto\tuna tabulación")
print("Un texto\nuna nueva línea")

# Podemos utilizar """ (triple comillas) para cadenas multilínea
print("""Una línea
otra línea
otra línea\tuna tabulación""")

# Dando formato a los datos que mostramos por consola
texto = "cualquiera"
numero = 20
cadena = "Un texto {} y un numero {}".format(texto, numero)
print(cadena)
cadenaInvertida = "Un texto '{1}' y un numero '{0}'".format(texto, numero)
print(cadenaInvertida)

# Alineando el texto a la derecha 30 caracteres
print("{:>30}".format("palabra"))

# Alineando el texto a la izquierda 30 caracteres
print("{:30}".format("palabra"))

# Alineando al centro 30 caracteres
print("{:^30}".format("palabra"))

# Para evitar los carácteres especiales, debemos indicar que una cadena es cruda (raw)
print(r"C:\nombre\directorio")

# Concatenando cadenas
print("Un divertido "+"programa "+"de "+ "radio")

# Multiplicar una cadena por un número
print(3 * "programas ")

# averiguar la longitud de una cadena
len("programas ")

# recorrer todos los caracteres de una cadena
for x in "programas ":
    print (x)

# Acceder a una posición de la cadena
nombre="Veronica"
print(nombre[1])

# Obteniendo Segmentos de cadenas
print(nombre[0:2])

# f-strings: formatted strings o cadenas formateadas:
a = 5
cadena_con_formato = f"Este es un numero entero {a}."
print(cadena_con_formato)

b = 199.9876543123456123456
cadena_con_formato = f"Este es un numero de punto flotante dificil de leer {b}."
print(cadena_con_formato)
cadena_con_formato = f"Este es un numero de punto flotante facil de leer {b:.5f}."
print(cadena_con_formato)

#Inmutabilidad
#Una propiedad de las cadenas es que no se pueden modificar. 
#Si intentamos reasignar un carácter, no nos dejará
#nombre[0] = "A" # -> Error




