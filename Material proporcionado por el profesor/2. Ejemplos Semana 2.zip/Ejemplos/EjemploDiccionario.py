# Defino la varible 'futbolistas' como un diccionario. No es necesario declarar que tipo de dato es
futbolistas = dict()

futbolistas = {1: "Casillas",
               15: "Ramos",
               3: "Pique",
               5: "Puyol",
               11: "Capdevila",
               14: "Xabi Alonso",
               16: "Busquets",
               8: "Xavi Hernandez",
               'Uno': "Pedrito",
               'Otro': "Iniesta",
               7: "Villa"
               }

print(futbolistas['Uno'])

# Recorrer un diccionario, imprimiendo su clave-valor
for k, v in futbolistas.items():
    print(f"Llave: {k} -> Valor: {v}")

# Vemos cuantos elementos tiene nuestro diccionario
num_elem = len(futbolistas)
print ("\nNumero de elementos del diccionario len(futbolistas) = %i" %num_elem)
print(f'\nNumero de elementos del diccionario = {num_elem}')

# Imprimimos una lista con las claves del diccionario
keys = futbolistas.keys()
key_list = list(futbolistas.keys())
futbolistas = {1: "Casillas",
               15: "Ramos",
               3: "Pique",
               5: "Puyol",
               11: "Capdevila",
               14: "Xabi Alonso",
               16: "Busquets",
               8: "Xavi Hernandez",
               'Uno': "Pedrito",
               'Otro': "Iniesta",
               7: "Villa"
               }
print (f"\nClaves del diccionario futbolistas.keys(): \n{keys}")
for key in futbolistas.keys():
    print(key)

# Imprimimos en una lista los valores del diccionario
values = futbolistas.values()
print ("\nValores del diccionario futbolistas.values(): \n%s"%values)

# Obtenemos el valor de un elemento dada su clave
elem = futbolistas.get(6)
print (f"\nObtenemos el valor cuya clave es '6' futbolistas.get(6): {elem}")

# Añadimos un nuevo elemento al diccionario
futbolistas[22] = 'Navas'
print (f"\nDiccionario tras añadir un elemento: futbolistas[22] = 'Navas' \n{futbolistas}")

# Eliminamos un elemento del diccionario dada su clave
futbolistas.pop(22)
print (f"\nDiccionario tras eliminar un elemento: futbolistas.pop(22) \n{futbolistas}")

# Hacemos una copia del diccionario
futbolistasCopy = futbolistas.copy();
print (f"\nRealizamos una copia del diccionario futbolistasCopy=futbolistas.copy(): \n{futbolistas}")

# Eliminamos los elementos de un diccionario
futbolistasCopy.clear()
print ("\nEliminamos los elementos de un diccionario futbolistasCopy.clear(): %s" %futbolistasCopy)

# Creamos un diccionario a partir de una lista con las claves
keys = ['nombre', 'apellidos', 'edad']
dictList = dict.fromkeys(keys, 'nada')
print ("\nCreamos un diccionario a partir de una lista dictList = dict.fromkeys(keys, 'nada'): \n%s" %dictList)

# Comprobamos si existe o no una clave con el valor 2
if 2 in futbolistas:
    print("Si existe la clave", 2)
else:
    print("No existe esa clave", 2)
# Comprobamos si existe o no una clave con el valor 8
if 8 in futbolistas:
    print("Si existe la clave", 8)
else:
    print("No existe esa clave", 8)

# Devolvemos los elementos del diccionario en tuplas
tuplas = futbolistas.items()
print (f"\nPasamos el diccionario a tuplas con clave-valor: tuplas = futbolistas.items() \n{tuplas}")

# Unimos dos diccionarios
suplentes = {
    4:'Marchena', 9:'Torres', 12:'Valdes',
    13:'Mata' , 17:'Arbeloa', 19:'Llorente',
    20:'Javi Martinez', 21:'Silva', 23:'Reina'
}

futbolistas.update(suplentes)
print (f"\nAñadimos los elementos de un diccionario a otro futbolistas.update(suplentes): \n{futbolistas}")
