#TUPLAS
# Ejemplo con la lista
lista_a = [1, 2, 3, 4, 'Esther']
print(lista_a[-1])


#Creando tuplas
tupla1 = (1,2,3,4)
tupla2 = 1,2,3,4

#Agregando objetos mutables a la tupla, en este caso metemos una lista
tupla3 = (1, "Pedro", [0,1,2])
print(tupla3)


#Accediendo a los datos de la tupla
print(tupla1[0])


#Modificando elementos mutables de la tupla
tupla3[2][2] = 3
print(tupla3)


#Las tuplas son inmutables no podemos modificar o eliminar elementos ya creados
del tupla3[0]


# Recorriendo la tupla y mostrando los valores
for valor in tupla1:
    print(valor)