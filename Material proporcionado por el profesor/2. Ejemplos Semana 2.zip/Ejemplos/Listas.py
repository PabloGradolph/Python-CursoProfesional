#LISTAS

#En una lista podemos mezclar tipos de datos
lista_a = ['Hola', 3, 4, 1]
print(lista_a)
print(type(lista_a))
#Agregando datos a la lista ya creada
lista_a += ['adios', False]
print(lista_a)

lista_a.append(56)
lista_a.append('Pedro')
print(lista_a)

#Agregando varios datos a la vez
otra_lista = ['Marta', 100, 'Marta']
lista_a.extend(otra_lista)
print(lista_a)

#Eliminando datos de la lista
lista_a.remove('Marta')
lista_a.remove('Marta')
print(lista_a)

# Creando listas mediante el metodo list()
lista_nombre = list('Esto es un texto largo.')
print(lista_nombre)

# Metodo split para crear una lista a partir de una frase
frase = "Hola como estas"
print(frase.split())

#Separamos mediante un delimitador dentro de split
frase = "Pizza, hamburguesa, ensalada"
print(frase.split(","))

#Metodo join para crear cadenas a partir de una lista
bebidas = ["agua",
           "vino",
           "cerveza",
           "refresco"]

nueva_frase = "=---------=".join(bebidas)
print("Mis bebidas favoritas son:", nueva_frase)

#Devolviendo la posicion mediante un valor
frase = "Hola como estas".split()
print(frase)
print(frase.index("Hola"))

#Devolviendo una valor mediante su posicion
print(frase[0])

#Repitiendo los valores de la lista
frase = list('Hector')
print(frase * 10)

#Buscando valores con in
vocales = ["a", "e", "i", "u"]
if 'o' in vocales:
    vocales.remove('o')
    print(vocales)

print('Vocales al final', vocales)

print(f"¿Esta a en la lista?: {resultado}")

#RECORRIENDO LISTAS
#1ª FORMA DE RECORRER LA LISTA
vocales = ["a", "e", "i", "o", "u", "a"]
for vocal in vocales:
    print("Manera 1 : En la posicion: ", vocales.index(vocal), "esta el valor: ", vocal)
    print(f"Manera 2: En la posicion: {vocales.index(vocal)} esta el valor: {vocal}")

#2ª FORMA DE RECORRER LA LISTA
indice = 0
for vocal in vocales:
    print("En la posicion:", indice, " esta el valor: ", vocal)
    indice = indice + 1

#3ª FORMA DE RECORRER LA LISTA
vocales = ["a", "e", "i", "o", "u", "a"]
for indice, valor in enumerate(vocales):
    print(f'Valor: {indice}')

vocales = ["a", "e", "i", "o", "u", "a"]
print(vocales[-3])

frase = 'Hector'
print(frase[:])
