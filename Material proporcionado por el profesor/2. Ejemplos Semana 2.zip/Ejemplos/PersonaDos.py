class PersonaPepe():

    def saludar(self):
        print("Hola desde persona dos")

def print_especial():
    print('Al especial')

NUMERO = 48