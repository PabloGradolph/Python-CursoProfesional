from PersonaDos import PersonaPepe as PP, NUMERO as N  # importando el modulo PersonaDos
from paquete.PersonaTres import PersonaTres  # importando el modulo PersonaTres desde un paquete


class PersonaUno:

    def saludar(self):
        print("Hola desde persona uno")

'''
Esta funcidinfasjkdbflkdsjfgbkdsbgflkjsdfgblkdsj
'''
persona = PP()
personaTres = PersonaTres()
persona_uno = PersonaUno()
print(N)

persona_uno.saludar()
persona.saludar()
personaTres.saludar()
