class PersonaTres():

    def saludar(self):
        print("Hola desde persona tres")