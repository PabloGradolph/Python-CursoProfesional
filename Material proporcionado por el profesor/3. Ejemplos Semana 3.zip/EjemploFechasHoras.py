# FECHAS Y HORAS
import datetime

# Obteniendo la fecha actual
now = datetime.datetime.now()
print(now)

# Obteniendo datos por separado
print("Dia:", now.day)
print("Mes:", now.month)
print("Año:", now.year)
print("Hora:", now.hour)
print("Minuto:", now.minute)
print("Segundo:", now.second)

# Agregando dias al dia actual - Metodo timedelta
print(now + datetime.timedelta(days=5))
print(now + datetime.timedelta(days=5, minutes=30, hours=5))

# Formateando fechas
print(now.strftime("%d-%m-%Y %H:%M:%S"))
print(now.strftime("%d/%m/%Y %H:%M:%S"))

# Determinando la zona horaria
horaCentral = datetime.timezone(datetime.timedelta(hours=+1))
print(horaCentral)
