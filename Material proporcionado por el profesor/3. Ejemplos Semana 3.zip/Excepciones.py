
#EXCEPCIONES EN PYTHON

# Ejemplo 1 de excepciones
try:
    print("Dame un numero")
    numero1 = int(input())

    print("Dame otro numero")
    numero2 = int(input())
except ValueError: #se ejecuta este bloque cuando se produce un error
    print("Numero incorrecto")
else: #se ejecuta este bloque si todo ha ido bien
    print(numero1 + numero2)

# Ejemplo 2 de excepciones, obteniendo el tipo de error
try:
    n = input("Introduce un numero: ")
    5 / n
except Exception as e:
    print(type(e).__name__)

# Ejemplo 3 de excepciones, lanzando una excepcion nosotros mismos
# Comprobando valores nulos
def funcion(dato = None):
    if dato is None:
        raise ValueError("Error! No se permiten los valores nulos")

# Comprobando otros tipos de datos
def funcion(dato):
    if type(dato) == str:
        raise ValueError("Error! No se permiten cadenas")
    elif type(dato) == int:
        raise ValueError("Error! No se permiten numeros enteros")
    elif type(dato) == float:
        raise ValueError("Error! No se permiten numeros con decimales")

funcion(2.2)
#funcion(2)