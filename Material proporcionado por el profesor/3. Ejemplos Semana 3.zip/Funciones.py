# 1º. FUNCIONES SIN ARGUMENTOS

#Definicion de la funcion
def pedirPizza():
    print("Has pedido pizza")

#Llamada a la funcion
pedirPizza()

# 2º. FUNCIONES CON ARGUMENTOS
def pedirPizzaPersonalizada(ingrediente, extraQueso):
    if extraQueso == True:
        print("Has pedido una pizza con " + ingrediente + " y con extra de queso")
    else:
        print("Has pedido una pizza con " + ingrediente + " y sin extra de queso")

pedirPizzaPersonalizada("cebollas", False)

def greeting(name: str) -> str:
    return 'Hello ' + name

# 3º. FUNCIONES QUE RETORNAN DATOS
def sumar(numero1, numero2):
    return numero1 + numero2

suma = sumar(10, 2)
print(suma)

# Retornando distintos valores
def test():
    return  "una cadena", 20, [1,2,3]
print(test())
cadena,numero,lista = test()
print(cadena, numero, lista)

# 4º. PASANDO DATOS A LAS FUNCIONES
# Pasando datos indeterminados a la funcion, estos datos se transforman en una tupla
def datosIndeterminados(*args):
    for arg in args:
        print(arg)

datosIndeterminados(5,"hola",[1,2,3])

# Pasando datos indeterminados a la funcion, en modo diccionario
def datosIndeterminados(**kwargs):
    for kwarg in kwargs:
        print(kwarg, " - ", kwargs[kwarg])

datosIndeterminados(n=5, c="hola", l=[1,2,3])

# 5º. FUNCIONES RECURSIVAS
def cuentaAtras(numero):
    numero -= 1
    if numero > 0:
        print(numero)
        cuentaAtras(numero)
    else:
        print("Fin de la funcion recursiva")

cuentaAtras(5)

# 6º. PEDIR DATOS POR CONSOLA AL USUARIO
print("Introduce un numero:")
numeroUno = int(input())
print("Introduce otro numero:")
numeroDos = int(input())

print(sumar(numeroUno, numeroDos))

