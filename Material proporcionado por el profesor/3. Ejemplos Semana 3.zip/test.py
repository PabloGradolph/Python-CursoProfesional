def datospordefecto(a, b, save=False, apellido='Barrio'):
  print(a)
  print(b)
  if save:
      print('Guardando')
  return a

