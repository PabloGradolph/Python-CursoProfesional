# CLASES Y OBJETOS EN PYTHON

# 1º. Creando clases

class Persona:
    nombre = ""
    apellidos = ""
    edad = 0

    #Metodo constructor de la clase
    def __init__(self, nombre, apellidos, edad):
        self.nombre = nombre
        self.apellidos = apellidos
        self.edad = edad

    #Metodo destructor de la clase
    def __del__(self):
        print("Se acaba de borrar el objeto persona")

    #Metodo para redefinir el metodo str
    def __str__(self):
        return "Nombre: {} - Apellidos: {}".format(self.nombre, self.apellidos)

    #Metodos corrientes
    def saludar(self):
        print("Hola", self.nombre)


    def calculaJubilacion(self):
        return 65 - self.edad


persona = Persona("Pedro", "Perez", 36)
persona.saludar()
Ω = persona.calculaJubilacion()
print("Te quedan", Ω, "años para jubilarte")

#llamamos al metodo str
print(str(persona))