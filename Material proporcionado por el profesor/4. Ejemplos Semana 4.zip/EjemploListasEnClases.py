#Clase Persona

class Persona:

    def __init__(self, nombre, apellidos, edad):
        self.__nombre = nombre
        self.__apellidos = apellidos
        self.__edad = edad

    def __str__(self):
        return "Nombre: {} - Apellidos: {} - Edad: {}".format(self.__nombre, self.__apellidos, self.__edad)


#Creando objetos dentro de objetos
class ListaPersonas:
    listaPersonas = []

    def __init__(self, listaPersonas = []):
        self.listaPersonas = listaPersonas

    def agregar(self, persona):
        self.listaPersonas.append(persona)

    def mostrar(self):
        print("---- LISTA DE PERSONAS -----")
        for p in self.listaPersonas:
            print(p)
        print("---- FIN DE LA LISTA DE PERSONAS -----")

listaPersonas = ListaPersonas()
listaPersonas.agregar(Persona("Marta", "Alvarez", 56))
listaPersonas.agregar(Persona("Sergio", "Mendoza", 26))
listaPersonas.agregar(Persona("Leire", "Perez", 16))
listaPersonas.mostrar()