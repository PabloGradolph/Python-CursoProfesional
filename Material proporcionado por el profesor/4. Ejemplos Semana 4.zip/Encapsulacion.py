#Ejemplo encapsulacion
class Persona:

    #Definimos constructor con variables de clase privadas
    def __init__(self, nombre, apellidos):
        self.__nombre = nombre
        self.__apellidos = apellidos

    #Metodos getter y setter para poder tabajar con las variables de clase
    def setNombre(self, nom):
        self.__nombre = nom

    def getNombre(self):
        return self.__nombre

    def setApellidos(self, ape):
        self.__apellidos = ape

    def getApellidos(self):
        return self.__apellidos

    def saludar(self):
        print("Hola", self.getNombre(), self.getApellidos())



persona = Persona("Ana","Gutierrez")
nombre = persona.getNombre()
apellidos = persona.getApellidos()
print(nombre, apellidos)
