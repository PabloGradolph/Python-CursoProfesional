from PersonaUno import PersonaUno

#Definimos la clase hija o subclase
class PersonaDos(PersonaUno):
    def __init__(self, nombre, apellidos, dni, telefono):
        super().__init__(nombre, apellidos)
        self.__dni = dni
        self.__telelefono = telefono

    def setDni(self, dni):
        self.__dni = dni

    def getDni(self):
        return self.__dni

    def setTelefono(self, telefono):
        self.__telelefono = telefono

    def getTelefono(self):
        return self.__telelefono

    def saludarDos(self):
        print("Tus datos son:", self.getDni(), self.getTelefono())


perso = PersonaDos("Sergio", "Garcia", 444444, 555555)
perso.saludarUno() #  antes del metodo set
perso.setApellidos("Ramirez")
perso.saludarUno()
perso.saludarDos()
