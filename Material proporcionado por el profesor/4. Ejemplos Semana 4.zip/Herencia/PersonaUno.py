#Definimos la clase padre o superclase
CONSTANTE = 82

class PersonaUno:

    def __init__(self, nombre, apellidos):
        self.__nombre = nombre
        self.__apellidos = apellidos

    def setNombre(self, nom):
        self.__nombre = nom

    def getNombre(self):
        return self.__nombre

    def setApellidos(self, ape):
        self.__apellidos = ape

    def getApellidos(self):
        return self.__apellidos

    def saludarUno(self):
        print("Hola", self.getNombre(), self.getApellidos())

per = PersonaUno("Pedro","Perez")
per.saludarUno()
