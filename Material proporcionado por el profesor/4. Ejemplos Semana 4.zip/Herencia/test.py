class Persona:
    # Definimos constructor con variables de clase privadas
    def __init__(self, nombre, apellidos):
        self.nombre = nombre
        self.apellidos = apellidos

    def set_nombre(self, n):
        if type(n) != str:
            print('No has introducido una cadena de caracters.')
            print('No ejecuto el cambio de nombre.')
            return
        self.nombre = n

    def get_nombre(self):
        return self.nombre

    def saludar(self):
        nombre = self.get_nombre()
        print(f'Hola soy {nombre}.')

class Empleado(Persona):
    def __init__(self, nombre, apellidos, salario):
        super().__init__(nombre, apellidos)
        self.salario = salario

    def get_salario(self):
        return self.salario

empleado_1 = Empleado('Francisco', 'Casas', 200)
empleado_1.saludar()