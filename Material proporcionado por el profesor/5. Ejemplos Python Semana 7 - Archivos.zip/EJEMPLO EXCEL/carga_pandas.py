import pandas as pd
import matplotlib.pyplot as plt

archivo = r'C:\Users\barri\Desktop\AEPI\PYTHON\PYTHON\CLASES\CLASE 7\EXCEL\ejemplo_pandas.xlsx'

dataframe = pd.read_excel(archivo)
print(dataframe)

dataframe.plot()
plt.show()