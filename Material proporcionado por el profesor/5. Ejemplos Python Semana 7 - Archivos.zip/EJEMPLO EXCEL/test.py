import pandas as pd
import matplotlib.pyplot as plt
archivo = r'C:\Users\barri\Desktop\AEPI\Python Basico Verano 2022\CLASE 7\EXCEL\ejemplo_pandas.xlsx'

dataframe = pd.read_excel(archivo)
print(dataframe)
dataframe.plot()
plt.show()
