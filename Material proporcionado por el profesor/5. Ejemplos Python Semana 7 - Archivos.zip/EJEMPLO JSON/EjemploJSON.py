import json

#Leyendo un fichero JSON

fichero = open(r"C:\Users\barri\Desktop\AEPI\Python Basico Verano 2022\CLASE 7\FICHEROS JSON\EJEMPLO\EjemploJSON\EjemploJSON\nuevo_album.json")
with fichero as file:
    linea = file.readline()
    datos = json.loads(linea)
    print(f'El tipo del objeto json es {type(datos)}')
    print(datos['albums']['titulos'])
    print(datos['albums']['genero'])

# Escribiendo nuevos datos en el fichero JSON
fichero = open(r"C:\Users\barri\Desktop\AEPI\Python Basico Verano 2022\CLASE 7\FICHEROS JSON\EJEMPLO\EjemploJSON\EjemploJSON\nuevo_album.json", "r")
nuevo_fichero = open(r"C:\Users\barri\Desktop\AEPI\Python Basico Verano 2022\CLASE 7\FICHEROS JSON\EJEMPLO\EjemploJSON\EjemploJSON\datos.json", "w")

with fichero as src, nuevo_fichero as dest:
    linea = src.readline()
    datos = json.loads(linea)
    for i in range(100):
        datos['albums']['titulos'].append(f'cancion Apendizada {i}')
    cadena = json.dumps(datos)
    dest.writelines(cadena)

print(datos)

#Creando un nuevo fichero JSON a partir del anterior
datos['albums']['titulos'].append('cancion Nueva')
cadena = json.dumps(datos)
print(cadena)
nuevo_fichero = open("nuevo_archivo.json", "w")
nuevo_fichero.writelines(cadena)
nuevo_fichero.close()