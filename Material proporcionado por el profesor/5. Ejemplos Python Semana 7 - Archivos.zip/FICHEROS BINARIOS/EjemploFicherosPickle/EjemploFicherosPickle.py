# El módulo pickle
# Guardar estructura o colecciones en ficheros binarios
import pickle
import sys

with open('lista.pckl', 'rb') as fichero:
    print(f'Binario: {fichero.read()}')
    sys.stdout.buffer.write(fichero.read())

with open('lista.pckl', 'r') as fichero:
    print(f'Texto: {fichero.read()}')





lista = [1, 2, 3, 4, 5]
# Podemos guardar lo que queramos, listas, diccionarios, tuplas...
fichero = open('lista.pckl', 'wb')
# Escritura en modo binario, vacía el fichero si existe
pickle.dump(lista, fichero)
# Escribe la estructura en el fichero
fichero.close()

# Recuperar estructura de fichero binario
fichero = open('lista.pckl', 'rb')  # Lectura en modo binario
lista_fichero = pickle.load(fichero)
print(lista_fichero)

#Lógica para trabajar con objetos
#1º. Crear una colección
#2º. Introducir los objetos en la colección
#3º. Guardar la colección haciendo un dump
#4º. Recuperar la colección haciendo un load
#5º. Seguir trabajando con nuestros objetos

class Persona:
    def __init__(self, nombre):
        self.nombre = nombre
    def __str__(self):
        return self.nombre

nombres = ["Héctor", "Mario", "Marta"]
personas = []

for n in nombres:
    p = Persona(n)
    personas.append(p)

import pickle

f = open('personas.pckl', 'wb')
pickle.dump(personas, f)
f.close()

f = open('personas.pckl', 'rb')
personas = pickle.load(f)
f.close()
for p in personas:
    print(p)