import os
print(f'Directorio con os.getcwd: {os.getcwd()}')

directorio = os.path.dirname(os.path.abspath(__file__))
print(f'Directorio con __file__: {directorio}')

import os
directorio_actual = os.getcwd()
nombre_objetivo = 'hola.txt'

for raiz, dirs, archivos in os.walk(directorio_actual):
  print('--------------------------------')
  print(f'Raiz:{raiz}')
  print(f'Directorios:{dirs}')
  print(f'Archivos:{archivos}')
  print('--------------------------------')

  if nombre_objetivo in archivos:
    print(f'Esta Aqui: {raiz}')
    loquebuscaba = raiz

ruta_completa = os.path.join(loquebuscaba, nombre_objetivo)
print(ruta_completa)

#Crear fichero y escribir texto
texto = "Una linea con texto\nOtra linea con texto\nEsta son las lineas que añado"
fichero = open(ruta_completa, 'a')  # fichero.txt ruta donde lo crearemos, w indica modo de escritura, write (puntero principio)
fichero.write(texto)
fichero.close()

texto = "Texto Nuevo España Camión\n"
fichero2 = open(ruta_completa, 'a')# escribimos el texto
fichero2.write(texto)
fichero2.close()  # cerramos el fichero

#Lectura de un fichero de texto
fichero = open(ruta_completa, 'r')  # modo lectura read, por defecto ya es r, no es necesario
texto = fichero.read() # lectura completa
fichero.close()
print(texto)
print(texto.encode('utf8').decode('latin1'))

ruta = r'EJEMPLO/EjemploFicheros/EjemploFicheros/fichero.txt'
fichero = open(ruta, 'r')
texto_como_lineas = fichero.readlines() # leer creando una lista de líneas
fichero.close()
print(texto_como_lineas)
print(texto_como_lineas[-1]) # Última línea

#Extensión de un fichero de texto
fichero = open(ruta, 'a')  # modo a, append, añadir - extender (puntero al final)
fichero.write('\nUna line adicional mas ----')
fichero.close()

#Lectura de un fichero no existente, nos genera la excepcion de tipo FileNotFoundError
fichero = open('fichero_inventado.txt', 'r')
fichero = open('fichero_inventado.txt', 'a+')  # Extensión con escritura simultánea, crea fichero si no existe
fichero.close()

#Lectura línea a línea
fichero = open('fichero.txt','r')
fichero.readline()   # Línea a línea
fichero.readline()
fichero.readline()
fichero.close()

#Lectura línea a línea secuencial
with open("fichero_nuevo.txt", "r") as f:
    for linea in f:
        print(linea)

#Manejando el puntero
fichero = open('fichero.txt', 'r')
fichero.seek(6) # Puntero al principio
print(fichero.read(10)) # Leemos 10 carácteres
print(fichero.read(10)) # Leemos 10 carácteres más, a partir del 10 donde está el puntero
fichero.seek(0)
print(fichero.read(5))
print(fichero.seek(len(fichero.readline()))) # Leemos la primera línea y situamos el puntero al principio de la segunda
print(fichero.read())
fichero.close()

#Lectura y escritura a la vez
fichero2 = open('fichero2.txt', 'w')
texto = "Línea 1\nLínea 2\nLínea 3\nLínea 4"
fichero2.write(texto)
fichero2.close()
fichero2 = open('fichero2.txt', 'a+')  # + escritura simultánea, puntero al principio por defecto
fichero2.write('asdfgh')
fichero2.close()

# Modificar una línea específica
fichero2 = open('fichero2.txt', 'r+')  # modo lectura con escritura, puntero al principio por defecto
texto = fichero2.readlines() # leemos todas las líneas
texto[2] = "Esta es la línea 3 modificada****\n"  # indice menos 1
fichero2.seek(0) # Ponemos el puntero al principio
fichero2.writelines(texto)
fichero2.close()

fichero_trabajo = open('fichero2.txt', 'r')
# modo lectura con escritura, puntero al principio por defecto
with fichero_trabajo as f:
  # leemos todas las líneas
  texto = f.readlines()
  # indice menos 1
  texto[2] = "----Esta es la línea 3 modificada con WITH--OTRA VEZ-\n"

fichero_trabajo = open('fichero2.txt', 'w')
with fichero_trabajo as f:
  f.writelines(texto)



import os
directorio_actual = os.getcwd()
nombre_objetivo = 'hola.txt'

for raiz, dirs, archivos in os.walk(directorio_actual):
  print('--------------------------------')
  print(f'Raiz:{raiz}')
  print(f'Directorios:{dirs}')
  print(f'Archivos:{archivos}')
  print('--------------------------------')

  if nombre_objetivo in archivos:
    print(f'Esta Aqui: {raiz}')
    loquebuscaba = raiz

ruta_completa = os.path.join(loquebuscaba, nombre_objetivo)
print(ruta_completa)
# Extra lectura escritura simultanea:
with open(ruta_completa, 'r') as src, open('fichero2.txt', 'a') as dst:
  linea = src.readline()
  while linea != '':
    linea = src.readline()
    if 'Texto' in linea:
      res = linea[4:10]
      dst.write(res +'\n')

with open(ruta_completa, 'r') as l:
  with open('fichero2.txt', 'w') as e:
    linea = l.readline()
    while linea != '':
      linea = l.readline()
      if 'texto' in linea:
        res = linea[12:15]
        e.write(res +'\n')