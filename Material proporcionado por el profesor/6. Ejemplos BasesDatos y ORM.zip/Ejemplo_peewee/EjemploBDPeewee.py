from peewee import *
from datetime import date

db = SqliteDatabase('personas.db')

class Persona(Model):
    nombre = CharField()
    fechaNacimiento = DateField()
    esRelativo = BooleanField()

    class Meta:
        database = db # This model uses the "personas.db" database.

class Mascota(Model):
     propietario = ForeignKeyField(Persona, related_name='pets')
     nombre = CharField()
     tipoAnimal = CharField()

     class Meta:
         database = db

def crearConectar():
    db.connect()
    db.create_tables([Persona, Mascota], safe=True)

def insertarRegistro():
    persona = Persona(nombre = "Juan", fechaNacimiento = date(3000, 11, 13), esRelativo = True)
    persona.save()

    persona2 = Persona.create(nombre = "Marta", fechaNacimiento = date(2015, 10, 1), esRelativo = False)
    kira = Mascota.create(propietario = persona, nombre = "Kira", tipoAnimal = "Perro")
    charly = Mascota.create(propietario = persona2, nombre = "charly", tipoAnimal = "Perro")

#Obtener todos los registros
def obtenerPersonas():
    for persona in Persona.select():
        print("Nombre: {} - fecha de nacimiento: {}".format(persona.nombre, persona.fechaNacimiento))

#Obtener todos los registros que coincidan con el condicional where
def obtenerUnaPersona(nombre):
    registro = Persona.get(Persona.nombre == nombre)
    print("Fecha de nacimiento del registro consultado:", registro.fechaNacimiento)

#Obtener todos los registros que coincidan con el condicional where
def obtenerPersona(nombre):
    registro = Persona.select().where(Persona.nombre == nombre)
    print("--------------- REGISTROS ----------------")
    for dato in registro:
        print(dato.nombre, dato.fechaNacimiento)
    print("------------------------------------------")

def eliminarUnRegistro(nombre):
    query = Mascota.delete().where(Mascota.nombre == nombre)
    registrosBorrados = query.execute()
    print("{} Registros borrados".format(registrosBorrados))

crearConectar()
#insertarRegistro()
#obtenerPersonas()
#obtenerPersona("Juan")
#obtenerUnaPersona("Juan")
eliminarUnRegistro("charly")
