import sqlite3

class BaseDatos:

    def __init__(self):
        self.database = []

    def conectar(self):
        self.database = sqlite3.connect("datos.sqlite")

    def create_table(self, n_tabla='datos'):
        try:
            nombre_tabla = n_tabla
            cursor = self.database.cursor()
            cursor.execute(f'''CREATE TABLE {nombre_tabla} (nombre text, apellidos text)''')
        except:
            pass

    def insertar(self, nombre, apellidos):
        cursor = self.database.cursor()
        cursor.execute("INSERT INTO datos (nombre,apellidos) VALUES ('" + nombre + "','" + apellidos + "')")
        self.database.commit()

    def insertarDos(self, nombre, apellidos):
        cursor = self.database.cursor()
        cursor.execute("INSERT INTO datos (nombre,apellidos) VALUES (?,?)",
                       (nombre, apellidos))
        self.database.commit()

    def visuazarTodo(self):
        database.row_factory = sqlite3.Row
        cursor_agenda = self.database.cursor()
        cursor_agenda.execute("SELECT * FROM datos")
        resultados = cursor_agenda.fetchall()
        for registro in resultados:
            print("Nombre:", registro['nombre'])
            print("Apellidos:", registro['apellidos'])
            print("------------------------")

    def visualizarUnRegistro(self, nombre):
        database.row_factory = sqlite3.Row
        cursor_agenda = database.cursor()
        cursor_agenda.execute("SELECT * FROM datos WHERE nombre = '" + nombre + "'")
        registro = cursor_agenda.fetchone()
        if registro != None: # comprobamos que el cursor contiene datos
            print("Nombre:", registro['nombre'])
            print("Apellidos:", registro['apellidos'])
        else:
            print("La consulta no ha devuelto ningun resultado")

    def eliminar(self, nombre):
        cursor = database.cursor()
        cursor.execute ("DELETE FROM datos WHERE nombre = '%s'" % (nombre))
        database.commit()

    def actualizar(self, nombre, nombre_nuevo):
        cursor = database.cursor()
        cursor.execute ("UPDATE datos SET nombre = '%s' WHERE nombre = '%s'" % (nombre_nuevo, nombre))
        database.commit()

    def cerrarConexion(self):
        cursor.close()
        database.close()

bd = BaseDatos()
bd.conectar()
bd.create_table()
bd.insertar("sergio","garcia")
bd.insertarDos("leire","jimenez")
print("-----VISUALIZANDO TODO-----")
bd.visuazarTodo()
print("-----VISUALIZANDO UN REGISTRO-----")
bd.visualizarUnRegistro("sergio")
print("-----ELIMINANDO UN REGISTRO-----")
bd.eliminar("jesus")
print("-----ACTUALIZANDO UN REGISTRO-----")
bd.actualizar("sergio","perico")
bd.visuazarTodo()
bd.cerrarConexion()