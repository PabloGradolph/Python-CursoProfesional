import sqlite3
conn = sqlite3.connect('ejemplo.db')
cursor = conn.cursor()

# Borrar una tabla si ya existe:
cursor.execute("DROP TABLE IF EXISTS EMPLEADOS")

# Crear una tabla:
sql = '''CREATE TABLE EMPLEADOS(
 NOMBRE CHAR(20) NOT NULL,
 APELLIDO CHAR(20),
 EDAD INT, 
 SALARIO FLOAT)'''
cursor.execute(sql)
print("Tabla creada con exito........")
# Commit cambios,
conn.commit()
# Cerrar la conexion
conn.close()


conn = sqlite3.connect('ejemplo.db')
cursor = conn.cursor()
cursor.execute('''INSERT INTO EMPLEADOS(NOMBRE, APELLIDO, EDAD, SALARIO)
                  VALUES ('Hector', 'Barrio', 41, 0)''')
cursor.execute('''INSERT INTO EMPLEADOS(NOMBRE, APELLIDO, EDAD,
SALARIO) VALUES ('Luis', 'Gomez', 21, 100)''')
conn.commit()
# Cerrar la conexion
conn.close()

# Nuestro propio gestor de contextos:
class SQLite():
    def __init__(self, file='sqlite.db'):
        self.file=file

    def __enter__(self):
        self.conn = sqlite3.connect(self.file)
        self.conn.row_factory = sqlite3.Row
        return self.conn.cursor()

    def __exit__(self, type, value, traceback):
        self.conn.commit()
        self.conn.close()

with SQLite('example.db') as cur:
    print(cur.execute('select sqlite_version();').fetchall()[0][0])

print(conn.close())
print(cur.close())



conn = sqlite3.connect('ejemplo.db')
cursor = conn.cursor()
cursor.execute('''SELECT * from EMPLEADOS''')
result = cursor.fetchone()
print(result)
result = cursor.fetchall();
print(result)
conn.commit()
conn.close()

# Cogiendolos Todos:
conn = sqlite3.connect('ejemplo.db')
cursor = conn.cursor()
cursor.execute('''SELECT * from EMPLEADOS''')
result = cursor.fetchall()
print(result)
conn.commit()
conn.close()

conn = sqlite3.connect('ejemplo.db')
cursor = conn.cursor()
cursor.execute("SELECT * from EMPLEADOS WHERE EDAD <40")
print(cursor.fetchall())
conn.commit()
2