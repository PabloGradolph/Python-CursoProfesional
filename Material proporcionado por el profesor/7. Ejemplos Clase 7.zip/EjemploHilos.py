import threading
import time

# EJEMPLO DE HILOS
def contar(lag):
    '''Contar hasta 25'''
    contador = 0
    while contador < 25:
        start_counting = time.time()
        contador += 1
        valor = int(input('Inserta un numero rapido'))
        #time.sleep(lag)
        stop_counting = time.time()
        tiempo_proceso = stop_counting - start_counting

        # El metodo getName nos retorna el nombre del hilo que se esta ejecutando
        # Si esta tachado, es que esta bajo aviso de "deprecation",
        # cambiara en la siguiente version del modulo.
        # Podemos usar: threading.current_thread().name
        print(threading.current_thread().getName(),
             'con identificador:', threading.current_thread().ident,
             'Contador:', contador, '\nHas tardado ', tiempo_proceso)

    nombre_hilo = threading.current_thread().name
    print(f'******Hilo {nombre_hilo} ha finalizado!******')


# target nos permite indicarle que funcion se va a ejecuta en el hilo
hilo1 = threading.Thread(target=contar, args=[0.3])
hilo1.name = "Proceso Rapido."

hilo2 = threading.Thread(target=contar, args=[0.6])
hilo2.name = "Proceso Lento."

hilo1.start()
hilo2.start()

'''
for i in range(15):
    print(f'Hola N {i} - Parando 0.5s')
    time.sleep(0.5)
'''

if hilo1.is_alive():
    print("El hilo 1 esta vivo\n")
