import threading
import time

class MiHilo1(threading.Thread):
    # Funcion inicio del hilo
    def __init__(self):
        threading.Thread.__init__(self)
        self.stoprequest = threading.Event()
        #podemos asignar un nombre personalizado al hilo
        self.name = "*******Hilo 1***********\n"

    def run(self):
        for i in range(0, 10):
            # dormimos el hilo para dar oportunidad a los demas hilos
            # tiempo en segundos
            # quitamos esta linea despues para ver que no van en paralelo
            time.sleep(0.5)
            print(f'Hilo: {self.name} contando por {i}')


class MiHilo2(threading.Thread):
    # Funcion inicio del hilo
    def __init__(self):
        threading.Thread.__init__(self)
        self.stoprequest = threading.Event()
        #podemos asignar un nombre personalizado al hilo
        self.name = "*******Hilo 2***********\n"

    def run(self):
        for i in range(0, 10):
            # dormimos el hilo para dar oportunidad a los demas hilos
            # tiempo en segundos
            # quitamos esta linea despues para ver que no van en paralelo
            # time.sleep(7)
            print(f'Hilo: {self.name} contando por {i}')

hilo1 = MiHilo1()
hilo2 = MiHilo2()
hilo1.start()
hilo1.join()
hilo2.start()

# podemos asignar prioridades a los hilos mediante join
#

