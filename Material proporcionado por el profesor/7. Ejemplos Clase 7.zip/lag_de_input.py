import threading
import time

# EJEMPLO DE HILOS
def contar(lag):
    '''Contar hasta 25'''
    contador = 0
    tiempo_acumulado = 0
    while contador < 25:
        start_counting = time.time()
        contador += 1
        if lag == 'input':
            _ = input('Inserta un numero rapido:')
        else:
            time.sleep(lag)
        stop_counting = time.time()
        tiempo_proceso = stop_counting - start_counting

        tiempo_acumulado = tiempo_acumulado + tiempo_proceso
        print(threading.current_thread().getName(),
             'con identificador:', threading.current_thread().ident,
             'Contador:', contador, '\nHan pasado: ', tiempo_acumulado, ' segundos.\n')

    nombre_hilo = threading.current_thread().name
    print(f'******Hilo {nombre_hilo} ha finalizado!******')


# target nos permite indicarle que funcion se va a ejecuta en el hilo
hilo1 = threading.Thread(target=contar, args=[5])
#hilo1.name = "Proceso Rapido."

hilo2 = threading.Thread(target=contar, args=['input'])
#hilo2.name = "Proceso Lento."

hilo1.start()
hilo2.start()
