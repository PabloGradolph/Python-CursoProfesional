import tkinter as tk

window = tk.Tk()
# Podemos ir moviendo el inicio -> window.mainloop()
window.title("Bienvenidos a la App.")
window.geometry('700x400')

fonts = ['Comic Sans MS', 'Arial']

etiqueta1 = tk.Label(window, text="Hola otra vez 1,1", font=(fonts[0], 50))
etiqueta1.grid(column=0, row=1)

etiqueta2 = tk.Label(window, text="Hola en el 0,0", font=(fonts[1], 25))
etiqueta2.grid(column=0, row=0)

fichero = open('texto.txt', 'r')

def clicked1():
    texto = fichero.readline()
    etiqueta1.configure(text=texto, font=(fonts[-1], 40))

boton1 = tk.Button(window, text="Click Aqui", command=clicked1)
boton1.grid(column=1, row=0)

entrada = tk.Entry(window, width=10)
entrada.grid(column=1, row=3)

def resetear_archivo():
    fichero.seek(0)

btn2 = tk.Button(window, text="Leer Texto", command=resetear_archivo)
btn2.grid(column=2, row=3)

window.mainloop()

'''
Para crear un ejecutable portable:
En la terminal:
pip install pyinstaller
pyinstaller --onefile tkinter_example.py
# el ejecutable estara en el directorio /dist
'''